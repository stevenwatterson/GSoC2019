function[y,t] = AtherosclerosisPathway2016Years(str, lpp, flux, rct, initialConditions)
if(exist('lpp'))
    lipoproteinProfile = lpp;
else
    lipoproteinProfile = 'high';
end

if(~exist('flux', 'var'))
    flux = 0;
end

if(~exist('rct', 'var'))
    rct = 0;
end

if(~exist('initialConditions', 'var'))
    %initialConditions = [190000 0 0 10 500 10 10 10 1000000 40000 0 0 0 150000 20000 20000 0 0 10 100 1 0 125000 50000 400000 500000 0 1 1 1 1 1 1 1 1 1 100 250 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 10 10 10 10 10 0 10 0 25000 10 10 0 20 20 0 0 0 20 0 0 0 20 0 0 2000 0 146000 10 1 1];
    %initialConditions(67) = 1000;
    %initialConditions(24) = initialConditions(24) * 2.2;
	load initialConditions;
end

timePeriod = 0:1:(80*365);
%initialConditions = [70000 0 0 10 500 10 10 10 0 60000 0 0 0 1 20000 0 0 0 10 100 1 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 10 10 10 10 10 0 10 0 0 10 10 0 20 20 0 0 0 20 0 0 0 20 0 0 0 0 146000 10 0];
options = odeset('NonNegative', 1:88);

fID = fopen('exp.txt','w');
if strcmp(lipoproteinProfile,'high')
    initialConditions(1) = 190 * 1000;
    initialConditions(10) = 40 * 1000;
end
if strcmp(lipoproteinProfile,'medhigh')
    initialConditions(1) = 150 * 1000;
    initialConditions(10) = 45 * 1000;
end
if strcmp(lipoproteinProfile,'med')
    initialConditions(1) = 110 * 1000;
    initialConditions(10) = 50 * 1000;
end
if strcmp(lipoproteinProfile,'medlow')
    initialConditions(1) = 70 * 1000;
    initialConditions(10) = 50 * 1000;
end
if strcmp(lipoproteinProfile,'low')
    initialConditions(1) = 50 * 1000;
    initialConditions(10) = 50 * 1000;
end


[v,x] = size(timePeriod);
%initialConditions = [100 0 0 10 1000 10 10 10 0 70 0 0 0];

inhibition = zeros(2,113);
inhibition(2, :) = 0.1;
%paras = [0.0000000000005 266 10625 123  0.10625 180625 0.0000004625 266 (0.027 * 5) 10500000 2 0.0000017886 62.5 0.00065 100 1.73 4.1472 0.00105125 0.0080375 0.0994 (18 * 30) (18 * 30*30) 6000000 6000000 0.0075 50 0.05 1200000 75000000 1200000 75000000 0.69 0.000000015 (3800 * 5) (2500 * 5) (1100 * 5) 950000000  125000000 65000000 130  0.000005  0.000005  0.00000625  0.03125  150000  225000  150000  2000  1650  0.0004  0.8  0.8  2  7.5  7.5  2  1  1  2  0.9  2  180  180  180  2  0.375  0.375  0.375  0.375  2  0.375  0.375  0.375  0.375  2  2  2  21  2  0.03  0.03  0.03  100000  2  0.06  0.06  0.06  0.06  0.06  0.06 0.02  2.2  2.2  2.2  2.2  2  0.002   4.32  0.4  4.32  0.0004  4.32  20  4.32  0.25  4.32  0.0000001  0.0000001  0.0000001  0.0000001  0.0000001  0.0000001  0.0000001  0.0000001  0.0000001  200  20  200  20  200  20  200  20  0.0033125  0.0003125  0.0042  0.0003125  0.15  2.4  0.000000257  25  0.0333  0.000000257  9000  500  500  0.144  10.125  0.03125  0.0000006  0.0003125  0.0003125  0.0003125  0.000856  0.03125  0.0001125  0.0006125  0.01  1  0.016  0.00000003125  0.0000000003125  0.000000025125  0.000000025125  0.00000000003125  0.00000000003125  0.000000015  0.33 30  2  8.097  100000  100000  8.1882  100000  100000  0.644  100000  66.435  1000000  1000000  0.000014  0.00625  1938  100000  2  50000  10000 1000000  0.375] ;
load paras;
[t1,y1] = ode23t(@AtheroEqnYearsInhibition, timePeriod, initialConditions, options, flux, inhibition);
[t,y] = ode23t(@AtheroEqnYears, timePeriod, initialConditions, options, flux, inhibition);
[t2,y2] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditions, options, flux, paras);
%save('savedData');
clf;

if(rct)
    delete('rct2.txt');
    newIC = y(365*40, :);
    newIC(1) = 50 * 1000;
    newIC(10) = 70 * 1000;
    [tRCTHL,resultsRCTHighLow] = ode23t(@AtheroEqnYears, 0:365*40, newIC, options);
    newResults = y(1:365*40, :);
    newResults(size(newResults,1) + 1: size(newResults,1) + size(resultsRCTHighLow,1), :) = resultsRCTHighLow;
    y = newResults;
end

%plot(t, y(:,1), t, y(:,2), t, y(:,4),  t, y(:,9), t, y(:,10), t, y(:,11), t, y(:,12), t, y(:,13), t, y(:,14) , t, y(:,16) , t, y(:,17) , t, y(:,18) , t, y(:,20), t, y(:,21), t, y(:,22)), title('Atherosclerosis Pathway');
if strcmp(str,'full')
    plot(t, y(:,1), t, y(:,2), t, y(:,4),  t, y(:,9), t, y(:,10), t, y(:,11), t, y(:,12), t, y(:,13));
    legend('LDL Lumen', 'LDL Intima','Proteoglycans', 'oxLDL', 'HDL Lumen', 'HDL Intima', 'oxHDL');
    [a,b] = max(y(x,:))
elseif strcmp(str, 'test')
    plot(t, y(:,2), t, y(:,3), t , y(:,9),  t , y(:,5));
    legend('LDL', 'PBLDL', 'oxLDL', 'free oxygen');
    
    %plot(t, y(:,14),t, y(:,17), t, y(:,22), t , y(:,18))
    %legend( 'Mono L', 'Mono I', 'Macro', 'Foam');
    
    %plot(t, y(:,17), t, y(:,22), t , y(:,18));
    %legend('Mono I', 'Macro', 'Foam');
elseif strcmp(str, 'T')
    plot(t, y(:, 27), t, y(:,39), t , y(:,40), t, y(:,41), t , y(:,42), t, y(:,43), t , y(:,44));
    legend('Naive', 'Th1', 'Th2', 'Th17', 'TFH', 'TNK', 'TReg');
    
else
    for i = 1:size(str, 2)
        hold on;
        plot(t, y(:,str(i)));
        hold off;
    end;
end
%plot(t, y(:,1), t, y(:,2), t, y(:,4),  t, y(:,9), t, y(:,10), t, y(:,11), t, y(:,12), t, y(:,13)), title('Atherosclerosis Pathway');
fclose(fID);




