function output = AtheroReportGraphsForPaper(graphNo)
%model = AtherosclerosisPathway2016Years('full');
options = odeset('NonNegative', 1:88);
timePeriod = 0:1:365*80;
flux = 0;
%initialConditions = [190000 0 0 10 500 10 10 10 1000000 40000 0 0 0 150000 20000 20000 0 0 10 100 1 0 125000 50000 400000 500000 0 1 1 1 1 1 1 1 1 1 100 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 10 10 10 10 10 0 10 0 25000 10 10 0 20 20 0 0 0 20 0 0 0 20 0 0 2000 0 146000 10 1 1];
%initialConditions = [190000 0 0 10 500 10 10 10 1000000 40000 0 0 0 150000 20000 20000 0 0 10 100 1 0 125000 50000 400000 500000 0 1 1 1 1 1 1 1 1 1 100 250 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 10 10 10 10 10 0 10 0 25000 10 10 0 20 20 0 0 0 20 0 0 0 20 0 0 2000 0 146000 10 1 1];
%initialConditions(67) = 1000;
%initialConditions(24) =  initialConditions(24) * 2.2;
load initialConditions;
initialConditionsHigh = initialConditions;
initialConditionsHigh(1) = 190 * 1000;
initialConditionsHigh(10) = 45 * 1000;

%paras = [0.0000000000005 266 10625 123 0.10625 180625 0.0000004625 266 540 0.027 10500000 2 0.0000017886 62.5 0.00065 100 1.73 4.1472 0.00105125 0.0080375 0.0994 18 6000000 6000000 0.0075 50 0.05 700000 1300000 700000 1300000 0.69 0.000000015 100 77 27.5 950000000 650000000 65000000 0.78125 0.000005 0.000005 0.00000625 0.0003125 150000 150000 150000 250000 25000 0.0004 0.0000000007 0.0000000008 0.0000000000625 0.00000000001 0.000014 0.000000000000625 0.8 0.8 2 7.5 7.5 2 1 2 0.9 2 180 2 220 2 0.375 2 2 2 21 2 0.03 100000 2 0.06 0.06 0.06 0.06 0.06 0.06 0.02 2.2 2.2 2.2 2.2 2 0.002 4.32 0.4 4.32 0.0004 4.32 200 4.32 0.25 4.32 0.0000000001 0.0000000001  0.0000000001 0.0000000001 0.0000000001 0.0000000001 0.0000000001 0.0000000001 0.0000000001 200 20 200 20 200 20 200 20 0.0033125 0.0003125 0.0042 0.0003125 7500 2.4 0.01 0.000000257 4.5 0.0333 0 9500 800000 500000 0.144 0.03125 0.0003125 0.0000006 0.0003125 0.0003125 0.0003125 0.000856 0.03125 0.0003125 0.003125 0.01 1 0.016 0.00000003125 0.0000000003125 0.0000000000000003125 0.0000000000000003125 0.000000000003125 0.000000000003125 0.000000015 0.33 30 2];
%paras = [0.0000000000005 266 10625 123 0.10625 180625 0.0000004625 266 18*30 0.027 10500000 2 0.0000017886 62.5 0.00065 100 1.73 4.1472 0.00105125 0.0080375 0.0994 18 6000000 6000000 0.0075 50  0.05 700000 1300000 700000 1300000 0.69  0.000000015 100 77 27.5 950000000 650000000 65000000 0.78125 0.000005  0.000005 0.00000625 0.0003125 150000 150000 150000 250000 25000 0.0004 0.8  0.8 2 7.5 7.5 2 1 1 2 0.9 2 180 180 180 2 75 75 75 75 2 0.375 0.375 0.375 0.375 2 2 2 21 2 0.03 0.03 0.03 100000 2 0.06 0.06 0.06 0.06 0.06 0.06 0.02 2.2 2.2 2.2 2.2 2 0.002 4.32 0.4 4.32 0.0004 4.32 200 4.32 0.25 4.32 0.0000000001 0.0000000001 0.0000000001 0.0000000001 0.0000000001 0.0000000001 0.0000000001 0.0000000001 0.0000000001 200 20 200 20 200 20 200 20 0.0033125 0.0003125 0.0042 0.0003125 7500 2.4 0.000000257 4.5 0.0333 0 9500 800000 500000 0.144 0.03125 0.0003125 0.0000006 0.0003125 0.0003125 0.0003125 0.000856 0.03125 0.0003125 0.003125 0.01 1 0.016 0.00000003125 0.0000000003125 0.0000000000000003125 0.0000000000000003125 0.000000000003125 0.000000000003125 0.000000015 0.33 30 2 8.097 100000 100000 8.1882 100000 100000 0.644 100000 66.435 1000000 1000000 0.000014 0.00625 1938 100000 2 50000 10000 1000000 75];
paras = [0.0000000000005 266 10625 123  0.10625 180625 0.0000004625 266 (0.027 * 5) 10500000 2 0.0000017886 62.5 0.00065 100 1.73 4.1472 0.00105125 0.0080375 0.0994 (18 * 30) (18 * 30*30) 6000000 6000000 0.0075 50 0.05 1200000 75000000 1200000 75000000 0.69 0.000000015 (3800 * 5) (2500 * 5) (1100 * 5) 950000000  125000000 65000000 130  0.000005  0.000005  0.00000625  0.03125  150000  225000  150000  2000  1650  0.0004  0.8  0.8  2  7.5  7.5  2  1  1  2  0.9  2  180  180  180  2  0.375  0.375  0.375  0.375  2  0.375  0.375  0.375  0.375  2  2  2  21  2  0.03  0.03  0.03  100000  2  0.06  0.06  0.06  0.06  0.06  0.06 0.02  2.2  2.2  2.2  2.2  2  0.002   4.32  0.4  4.32  0.0004  4.32  20  4.32  0.25  4.32  0.0000001  0.0000001  0.0000001  0.0000001  0.0000001  0.0000001  0.0000001  0.0000001  0.0000001  200  20  200  20  200  20  200  20  0.0033125  0.0003125  0.0042  0.0003125  0.15  2.4  0.000000257  25  0.0333  0.000000257  9000  500  500  0.144  10.125  0.03125  0.0000006  0.0003125  0.0003125  0.0003125  0.000856  0.03125  0.0001125  0.0006125  0.01  1  0.016  0.00000003125  0.0000000003125  0.000000025125  0.000000025125  0.00000000003125  0.00000000003125  0.000000015  0.33 30  2  8.097  100000  100000  8.1882  100000  100000  0.644  100000  66.435  1000000  1000000  0.000014  0.00625  1938  100000  2  50000  10000 1000000  0.375] ;
%%Update paras
%paras(40) = 130;
%paras(44) = 0.03125;
%paras(48) = 2000;
%paras(49) = 2390;
%paras(133) = 0.000000257;
%%paras(138) = 10.125;
%paras(139) = 0.03125;
%paras(153) = 0.000000003125;
%paras(154) = 0.000000003125;

%paras(180) = 0.375;
%paras(66) = 0.375;
%paras(67) = 0.375;
%paras(68) = 0.375;
%paras(69) = 0.375;


%%%% Steve if you see this please don't murder me

[tH,resultsHigh] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsHigh, options, flux, paras);

initialConditionsMedHigh = initialConditions;
initialConditionsMedHigh(1) = 150 * 1000;
initialConditionsMedHigh(10) = 45 * 1000;

[tMH,resultsMedHigh] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedHigh, options, flux, paras);


initialConditionsMed = initialConditions;
initialConditionsMed(1) = 120 * 1000;
initialConditionsMed(10) = 45 * 1000;

[tM,resultsMed] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMed, options, flux, paras);

initialConditionsMedLow = initialConditions;
initialConditionsMedLow(1) = 70 * 1000;
initialConditionsMedLow(10) = 45 * 1000;

[tML,resultsMedLow] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedLow, options, flux, paras);

initialConditionsLow = initialConditions;
initialConditionsLow(1) = 50 * 1000;
initialConditionsLow(10) = 45 * 1000;

highFormat = 'k';
medFormat = 'k:';
lowFormat = 'k--';


[tL,resultsLow] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsLow, options, flux, paras);

if graphNo == 1
    plot(tH/365, resultsHigh(:, 65)/(10^4), highFormat, tM/365, resultsMed(:, 65)/(10^4), medFormat, tL/365, resultsLow(:, 65)/(10^4), lowFormat);
    
    entityToModel = 65;
    title('Smooth Muscle Cell Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 2
    plot(tH/365, resultsHigh(:, 22)/(10^4), highFormat, tM/365, resultsMed(:, 22)/(10^4), medFormat, tL/365, resultsLow(:, 22)/(10^4), lowFormat);
    title('Macrophage Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 3
    plot(tH/365, resultsHigh(:, 18)/(10^4), highFormat, tM/365, resultsMed(:, 18)/(10^4), medFormat, tL/365, resultsLow(:, 18)/(10^4), lowFormat);
    title('Foam Cell Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 4
    TCells = [27 39 40 41 42 43 44] ;
    a = resultsHigh(:, TCells);
    plot(tH/365, sum(resultsHigh(:, TCells),2)/(10^4), highFormat, tM/365, sum(resultsMed(:, TCells),2)/(10^4), medFormat, tL/365, sum(resultsLow(:, TCells),2)/(10^4), lowFormat)
    title('T Cell Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 5
    plot(tH/365, resultsHigh(:, 39)/(10^4), highFormat, tM/365, resultsMed(:, 39)/(10^4), medFormat, tL/365, resultsLow(:, 39)/(10^4), lowFormat);
    title('Th1 Cell Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 6
    plot(tH/365, resultsHigh(:, 14)/(10^5), highFormat, tM/365, resultsMed(:, 14)/(10^5), medFormat, tL/365, resultsLow(:, 14)/(10^5), lowFormat);
    title('Blood MCP-1 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Concentration (� 10^5 fg/ml blood)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 7
    plot(tH/365, resultsHigh(:, 23)/(10^5), highFormat, tM/365, resultsMed(:, 23)/(10^5), medFormat, tL/365, resultsLow(:, 23)/(10^5), lowFormat);
    title('Blood CXCL9 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Concentration (� 10^5 pg/ml blood)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 8
    plot(tH/365, resultsHigh(:, 24)/(10^5), highFormat, tM/365, resultsMed(:, 24)/(10^5), medFormat, tL/365, resultsLow(:, 24)/(10^5), lowFormat);
    title('Blood CXCL10 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Concentration (� 10^5 pg/ml blood)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 9
    plot(tH/365, resultsHigh(:, 25)/(10^5), highFormat, tM/365, resultsMed(:, 25)/(10^5), medFormat, tL/365, resultsLow(:, 25)/(10^5), lowFormat);
    title('Blood CXCL11 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Concentration (� 10^5 pg/ml blood)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 10
    plot(tH/365, resultsHigh(:, 86)/(10^5), highFormat, tM/365, resultsMed(:, 86)/(10^5), medFormat, tL/365, resultsLow(:, 86)/(10^5), lowFormat);
    title('Triglyceride Concentrations');
    xlabel('Number of Years');
    ylabel('Triglyceride Concentration (� 10^5 �g/ml blood)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
    ax = gca;
    ax.XLim= [0 80];
    ax.YLim= [0 3];
elseif graphNo == 11
    plot(tH/365, resultsHigh(:, 79), highFormat, tM/365, resultsMed(:, 79), medFormat, tL/365, resultsLow(:, 79), lowFormat);
    title('Chylomicron Concentrations');
    xlabel('Number of Years');
    ylabel('Triglyceride Concentration (� �g/ml blood)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 12
    plot(tH/365, resultsHigh(:, 67)/(10^3), highFormat, tM/365, resultsMed(:, 67)/(10^3), medFormat, tL/365, resultsLow(:, 67)/(10^3), lowFormat);
    title('Blood IL1B Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^3 fg/ml blood)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
%     ax = gca;
%     ax.XLim= [0 80];
%     ax.YLim= [0 2000];
elseif graphNo == 13
    plot(tH/365, resultsHigh(:, 68)/(10^4), highFormat, tM/365, resultsMed(:, 68)/(10^4), medFormat, tL/365, resultsLow(:, 68)/(10^4), lowFormat);
    title('Blood CCL5 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^4 pg/ml blood)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 14
    plot(tH/365, resultsHigh(:, 46)/(10^4), highFormat, tM/365, resultsMed(:, 46)/(10^4), medFormat, tL/365, resultsLow(:, 46)/(10^4), lowFormat);
    title('MMP1 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^4 fg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 15
    plot(tH/365, resultsHigh(:, 48)/(10^4), highFormat, tM/365, resultsMed(:, 48)/(10^4), medFormat, tL/365, resultsLow(:, 48)/(10^4), lowFormat);
    title('MMP9 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^4 fg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 16
    plot(tH/365, resultsHigh(:, 50)/(10^7), highFormat, tM/365, resultsMed(:, 50)/(10^7), medFormat, tL/365, resultsLow(:, 50)/(10^7), lowFormat);
    title('TIMP1 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^7 fg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 17
    plot(tH/365, resultsHigh(:, 28)/(10^4), highFormat, tM/365, resultsMed(:, 28)/(10^4), medFormat, tL/365, resultsLow(:, 28)/(10^4), lowFormat);
    title('IL1B Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^4 fg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 18
    plot(tH/365, resultsHigh(:, 32)/(10^6), highFormat, tM/365, resultsMed(:, 32)/(10^6), medFormat, tL/365, resultsLow(:, 32)/(10^6), lowFormat);
    title('IL6 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^6 fg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 19
    plot(tH/365, resultsHigh(:, 45)/(10^4), highFormat, tM/365, resultsMed(:, 45)/(10^4), medFormat, tL/365, resultsLow(:, 45)/(10^4), lowFormat);
    title('TNF-A Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^4 fg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 20
    plot(tH/365, resultsHigh(:, 29)/(10^4), highFormat, tM/365, resultsMed(:, 29)/(10^4), medFormat, tL/365, resultsLow(:, 29)/(10^4), lowFormat);
    title('IL2 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^4 fg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 21
    plot(tH/365, resultsHigh(:, 35)/(10^4), highFormat, tM/365, resultsMed(:, 35)/(10^4), medFormat, tL/365, resultsLow(:, 35)/(10^4), lowFormat);
    title('IL18 Concentrations');
    xlabel('Number of Years');
   ylabel('Protein Quantity (� 10^4 fg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 22
    plot(tH/365, resultsHigh(:, 33)/(10^3), highFormat, tM/365, resultsMed(:, 33)/(10^3), medFormat, tL/365, resultsLow(:, 33)/(10^3), lowFormat);
    title('IL10 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^3 fg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 23
    plot(tH/365, resultsHigh(:, 34)/(10^3), highFormat, tM/365, resultsMed(:, 34)/(10^3), medFormat, tL/365, resultsLow(:, 34)/(10^3), lowFormat);
    title('IL12 Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^3 fg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 24
    plot(tH/365, resultsHigh(:, 19)/(10^3), highFormat, tM/365, resultsMed(:, 19)/(10^3), medFormat, tL/365, resultsLow(:, 19)/(10^3), lowFormat);
    title('IFNG Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^3 fg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 25
    plot(tH/365, resultsHigh(:, 38)/(10^2), highFormat, tM/365, resultsMed(:, 38)/(10^2), medFormat, tL/365, resultsLow(:, 38)/(10^2), lowFormat);
    title('TGFB Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^2 ng/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 26
    plot(tH/365, resultsHigh(:, 54)/(10^2), highFormat, tM/365, resultsMed(:, 54)/(10^2), medFormat, tL/365, resultsLow(:, 54)/(10^2), lowFormat);
    title('Chymase Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^2 ng/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 27
    plot(tH/365, resultsHigh(:, 55)/(10^2), highFormat, tM/365, resultsMed(:, 55)/(10^2), medFormat, tL/365, resultsLow(:, 55)/(10^2), lowFormat);
    title('Tryptase Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^2 ng/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 28
    plot(tH/365, resultsHigh(:, 58)/(10^6), highFormat, tM/365, resultsMed(:, 58)/(10^6), medFormat, tL/365, resultsLow(:, 58)/(10^6), lowFormat);
    title('Elastin Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^6 pg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 29
    plot(tH/365, resultsHigh(:, 59)/(10^6), highFormat, tM/365, resultsMed(:, 59)/(10^6), medFormat, tL/365, resultsLow(:, 59)/(10^6), lowFormat);
    title('Collagen Concentrations');
    xlabel('Number of Years');
    ylabel('Protein Quantity (� 10^6 pg/mg tissue)');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
elseif graphNo == 30
     rtP = resultsHigh;
    resultsToPlot(1, :) = rtP(:, 18) + rtP(:, 22);
    resultsToPlot(2, :) = rtP(:,27) + rtP(:,39) + rtP(:,40) + rtP(:,41) + rtP(:,42) + rtP(:,43) + rtP(:,44);
    resultsToPlot(3, :) = rtP(:, 65);
    plot(tH/365, resultsToPlot(1, :) /(10^4), highFormat, tH/365, resultsToPlot(2, :) /(10^4), medFormat, tH/365, resultsToPlot(3, :) /(10^4), lowFormat);
    title('Relative Cell Concentrations (LDL - 190mg/dL)');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    h_legend = legend('Monocytes/Foam Cells', 'T Cells', 'Smooth Muscle Cells');
elseif graphNo == 31
    %Have to generate this one manually as I'm changing parameters and I don't have a way to consistantly do this yet
    %k_th1 = 0.00000000002;
    %k_th2 = 0.00000000001;

    paras(161) = paras(161) * 1.1;
    paras(164) = paras(164) * 0.9;
    
    [thTh1,resultsHighTh1] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsHigh, options, flux, paras);
    [tmhTh1,resultsMedHighTh1] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedHigh, options, flux, paras);
    [tmTh1,resultsMedTh1] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMed, options, flux, paras);
    [tmlTh1,resultsMedLowTh1] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedLow, options, flux, paras);
    [tlTh1,resultsLowTh1] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsLow, options, flux, paras);
    
    
    
    entityToModel = 18;
    plothandle = plot(tH/365, sum(resultsHigh(:, entityToModel),2)/(10^4), highFormat, tM/365, sum(resultsMed(:, entityToModel),2)/(10^4), medFormat, tL/365, sum(resultsLow(:, entityToModel),2)/(10^4), lowFormat, tH/365, sum(resultsHighTh1(:, entityToModel),2)/(10^4), highFormat, tM/365, sum(resultsMedTh1(:, entityToModel),2)/(10^4), highFormat, tL/365, sum(resultsLowTh1(:, entityToModel),2)/(10^4), highFormat);
    
    hold on;
    xvec = tH/365;
    yvecHigh = sum(resultsHighTh1(:, entityToModel),2)/(10^4);
    yvecMed = sum(resultsMedTh1(:, entityToModel),2)/(10^4);
    yvecLow = sum(resultsLowTh1(:, entityToModel),2)/(10^4);
    markers = plot(xvec(1:1000:end), yvecHigh(1:1000:end), 'o', xvec(1:800:end), yvecMed(1:800:end), 'p', xvec(1:1000:end), yvecLow(1:1000:end), 'd');
    hold off;
    for i = 1:3
    markers(i).MarkerFaceColor = 'black';
    markers(i).MarkerEdgeColor = 'black';
    end
    
    
    title('Foam Cell Concentrations - Th1/Th2 balance');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    h_legend = legend([plothandle(1:3);markers], 'LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL',  'LDL - 190 mg/dL Inc Th1', 'LDL - 120 mg/dL Inc Th1', 'LDL - 50 mg/dL Inc Th1');
    
elseif graphNo == 32
   plot(tH/365, resultsHigh(:, 17), highFormat, tM/365, resultsMed(:, 17), medFormat, tL/365, resultsLow(:, 17), lowFormat);
    title('Intimal Monocyte Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Abundance');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
    h_legend = legend('LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL');
    ax = gca;
    ax.XLim= [0 80];
    ax.YLim= [0 100];
elseif graphNo==33
    plot(tH/365, resultsHigh(:, 17), highFormat);
    h_legend = legend('Strumpet');
    title('DUMMY GRAPH DO NOT USE');
elseif graphNo == 34
    %Have to generate this one manually as I'm changing parameters and I don't have a way to consistantly do this yet
    %Reduced k_il12 by 90%
    
    paras(71) = paras(71) * 0.25;
    paras(72) = paras(72) * 0.25;
    paras(73) = paras(73) * 0.25;
    paras(74) = paras(74) * 0.25;
    
    [thIL12,resultsHighIL12] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsHigh, options, flux, paras);
    [tmhIL12,resultsMedHighIL12] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedHigh, options, flux, paras);
    [tmIL12,resultsMedIL12] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMed, options, flux, paras);
    [tmlIL12,resultsMedLowIL12] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedLow, options, flux, paras);
    [tlIL12,resultsLowIL12] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsLow, options, flux, paras);
    
    entityToModel = 65;
    plothandle = plot(tH/365, resultsHigh(:, entityToModel)/(10^4), highFormat, tM/365, resultsMed(:, entityToModel)/(10^4), medFormat, tL/365, resultsLow(:, entityToModel)/(10^4), lowFormat, tH/365, resultsHighIL12(:, entityToModel)/(10^4), 'k', tM/365, resultsMedIL12(:, entityToModel)/(10^4), 'k', tL/365, resultsLowIL12(:, entityToModel)/(10^4), 'k');
    
    hold on;
    xvec = tH/365;
    yvecHigh = sum(resultsHighIL12(:, entityToModel),2)/(10^4);
    yvecMed = sum(resultsMedIL12(:, entityToModel),2)/(10^4);
    yvecLow = sum(resultsLowIL12(:, entityToModel),2)/(10^4);
    markers = plot(xvec(1:1000:end), yvecHigh(1:1000:end), 'o', xvec(1:800:end), yvecMed(1:800:end), 'p', xvec(1:1000:end), yvecLow(1:1000:end), 'd');
    hold off;
    for i = 1:3
    markers(i).MarkerFaceColor = 'black';
    markers(i).MarkerEdgeColor = 'black';
    end
    
    title('Foam Cell Concentrations - Reduced IL12');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    h_legend = legend([plothandle(1:3);markers], 'LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL',  'LDL - 190 mg/dL Red IL12', 'LDL - 120 mg/dL Red IL12', 'LDL - 50 mg/dL Red IL12');
elseif graphNo == 35
    
    newICs = initialConditionsHigh;
    newICs(69) = 1;
    [tABCA1,resultsABCA1] = ode23t(@AtheroEqnYears, timePeriod, newICs, options);
    entityToModel = 18;
    plot(tH/365, resultsHigh(:, entityToModel)/(10^4), highFormat, tH/365, resultsABCA1(:, entityToModel)/(10^4), medFormat);
     title('Foam Cell Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    h_legend = legend('Normal ABCA1', 'Reduced ABCA1');
elseif graphNo == 36
    newICs = initialConditionsHigh;
    newICs(20) = 0;
    [tMCSF,resultsMCSF] = ode23t(@AtheroEqnYears, timePeriod, newICs, options);
    entityToModel = 18;
    plot(tH/365, resultsHigh(:, entityToModel)/(10^4), highFormat, tH/365, resultsMCSF(:, entityToModel)/(10^4), medFormat);
    title('Macrophage Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    h_legend = legend('Normal MCSF', 'Reduced MCSF');
elseif graphNo == 37
    %Have to generate this one manually as I'm changing parameters and I don't have a way to consistantly do this yet
    %Changed k_test = 1000;
    
    paras(28) = paras(28) * 0.5;
    paras(30) = paras(30) * 0.5;
    
    [thIFNG,resultsHighIFNG] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsHigh, options, flux, paras);
    [tmhIFNG,resultsMedHighIFNG] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedHigh, options, flux, paras);
    [tmIFNG,resultsMedIFNG] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMed, options, flux, paras);
    [tmlIFNG,resultsMedLowIFNG] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedLow, options, flux, paras);
    [tlIFNG,resultsLowIFNG] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsLow, options, flux, paras);
    
    
    entityToModel = [27 39 40 41 42 43 44];
    %entityToModel = 39;
    plot(tH/365, sum(resultsHigh(:, entityToModel),2)/(10^4), highFormat, tH/365, sum(resultsHighIFNG(:, entityToModel),2)/(10^4), medFormat);
    title('T Cell Concentrations - Reduced IFNG');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    h_legend = legend('Normal IFNG', 'Reduced IFNG');
elseif graphNo == 38
    %Have to generate this one manually as I'm changing parameters and I don't have a way to consistantly do this yet
    %Increase IL6
    
%     paras(62) = paras(62) * 2;
%     paras(63) = paras(63) * 2;
%     paras(64) = paras(64) * 2;
    paras(62) = paras(62) * 8;
    paras(63) = paras(63) * 8;
    paras(64) = paras(64) * 8;
    
    [thIL6,resultsHighIL6] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsHigh, options, flux, paras);
    [tmhIL6,resultsMedHighIL6] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedHigh, options, flux, paras);
    [tmIL6,resultsMedIL6] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMed, options, flux, paras);
    [tmlIL6,resultsMedLowIL6] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedLow, options, flux, paras);
    [tlIL6,resultsLowIL6] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsLow, options, flux, paras);

    entityToModel = 18;
    plothandle = plot(tH/365, sum(resultsHigh(:, entityToModel),2)/(10^4), highFormat, tM/365, sum(resultsMed(:, entityToModel),2)/(10^4), medFormat, tL/365, sum(resultsLow(:, entityToModel),2)/(10^4), lowFormat, tH/365, sum(resultsHighIL6(:, entityToModel),2)/(10^4), 'k', tM/365, sum(resultsMedIL6(:, entityToModel),2)/(10^4), 'k', tL/365, sum(resultsLowIL6(:, entityToModel),2)/(10^4), 'k');
    
    hold on;
    xvec = tH/365;
    yvecHigh = sum(resultsHighIL6(:, entityToModel),2)/(10^4);
    yvecMed = sum(resultsMedIL6(:, entityToModel),2)/(10^4);
    yvecLow = sum(resultsLowIL6(:, entityToModel),2)/(10^4);
    markers = plot(xvec(1:1000:end), yvecHigh(1:1000:end), 'o', xvec(1:800:end), yvecMed(1:800:end), 'p', xvec(1:1000:end), yvecLow(1:1000:end), 'd');
    hold off;
    for i = 1:3
    markers(i).MarkerFaceColor = 'black';
    markers(i).MarkerEdgeColor = 'black';
    end
    
    
    title('Foam Cell Concentrations - Atheroprotective IL6');
    xlabel('Number of Years');
     ylabel('Cell Abundance (� 10^4)');
    h_legend = legend([plothandle(1:3);markers], 'LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL',  'LDL - 190 mg/dL Inc IL6', 'LDL - 120 mg/dL Inc IL6', 'LDL - 50 mg/dL Inc IL6');

elseif graphNo == 39
    %Have to generate this one manually as I'm changing parameters and I don't have a way to consistantly do this yet

    paras(76) = paras(76) * 1.5;
    
    [thIL18,resultsHighIL18] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsHigh, options, flux, paras);
    [tmhIL18,resultsMedHighIL18] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedHigh, options, flux, paras);
    [tmIL18,resultsMedIL18] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMed, options, flux, paras);
    [tmlIL18,resultsMedLowIL18] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedLow, options, flux, paras);
    [tlIL18,resultsLowIL18] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsLow, options, flux, paras);

    entityToModel = 65;
    plothandle = plot(tH/365, sum(resultsHigh(:, entityToModel),2)/(10^4), highFormat, tM/365, sum(resultsMed(:, entityToModel),2)/(10^4), medFormat, tL/365, sum(resultsLow(:, entityToModel),2)/(10^4), lowFormat, tH/365, sum(resultsHighIL18(:, entityToModel),2)/(10^4), 'k', tM/365, sum(resultsMedIL18(:, entityToModel),2)/(10^4), 'k', tL/365, sum(resultsLowIL18(:, entityToModel),2)/(10^4), 'k');
   
        hold on;
    xvec = tH/365;
    yvecHigh = sum(resultsHighIL18(:, entityToModel),2)/(10^4);
    yvecMed = sum(resultsMedIL18(:, entityToModel),2)/(10^4);
    yvecLow = sum(resultsLowIL18(:, entityToModel),2)/(10^4);
    markers = plot(xvec(1:1000:end), yvecHigh(1:1000:end), 'o', xvec(1:800:end), yvecMed(1:800:end), 'p', xvec(1:1000:end), yvecLow(1:1000:end), 'd');
    hold off;
    for i = 1:3
    markers(i).MarkerFaceColor = 'black';
    markers(i).MarkerEdgeColor = 'black';
    end
    
    
    title('Smooth Muscle Cell Concentrations - Increased IL18');
    xlabel('Number of Years');
    ylabel('Cell Abundance (� 10^4)');
    h_legend = legend([plothandle(1:3);markers], 'LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL',  'LDL - 190 mg/dL Inc IL18', 'LDL - 120 mg/dL Inc IL18', 'LDL - 50 mg/dL Inc IL18');

elseif graphNo == 40
    newICs = initialConditionsHigh;
    newICs(5) = 0.0001;
    [tProt,resultsProt] = ode23t(@AtheroEqnYears, timePeriod, newICs, options);
    entityToModel = 9;
    plot(tH/365, resultsHigh(:, entityToModel)/(10^7), highFormat, tH/365, resultsProt(:, entityToModel)/(10^7), medFormat);
     title('OxLDL Concentrations');
    xlabel('Number of Years');
    ylabel('Lipoprotein Count (� 10^7)');
    h_legend = legend('Normal Proteoglycans', 'Reduced Proteoglycans');
elseif graphNo == 41
    %Have to generate this one manually as I'm changing parameters and I don't have a way to consistantly do this yet

    paras(133) = paras(133) * 2;
    
    [thColl,resultsHighColl] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsHigh, options, flux, paras);
    [tmhColl,resultsMedHighColl] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedHigh, options, flux, paras);
    [tmColl,resultsMedColl] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMed, options, flux, paras);
    [tmlColl,resultsMedLowColl] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedLow, options, flux, paras);
    [tlColl,resultsLowColl] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsLow, options, flux, paras);

    entityToModel = 59;
    plothandle = plot(tH/365, sum(resultsHigh(:, entityToModel),2)/(10^6), highFormat, tM/365, sum(resultsMed(:, entityToModel),2)/(10^6), medFormat, tL/365, sum(resultsLow(:, entityToModel),2)/(10^6), lowFormat, tH/365, sum(resultsHighColl(:, entityToModel),2)/(10^6), 'k', tM/365, sum(resultsMedColl(:, entityToModel),2)/(10^6), 'k', tL/365, sum(resultsLowColl(:, entityToModel),2)/(10^6), 'k');
    hold on;
    xvec = tH/365;
    yvecHigh = sum(resultsHighColl(:, entityToModel),2)/(10^6);
    yvecMed = sum(resultsMedColl(:, entityToModel),2)/(10^6);
    yvecLow = sum(resultsLowColl(:, entityToModel),2)/(10^6);
    markers = plot(xvec(1:1000:end), yvecHigh(1:1000:end), 'o', xvec(1:800:end), yvecMed(1:800:end), 'p', xvec(1:1000:end), yvecLow(1:1000:end), 'd');
    hold off;
    for i = 1:3
    markers(i).MarkerFaceColor = 'black';
    markers(i).MarkerEdgeColor = 'black';
    end
    title('Collagen Concentrations - Increased collagen remodelling');
    xlabel('Number of Years');
    ylabel('Protein Quantity  (� 10^6)');
    h_legend = legend([plothandle(1:3);markers], 'LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL',  'LDL - 190 mg/dL Inc CM', 'LDL - 120 mg/dL Inc CM', 'LDL - 50 mg/dL Inc CM');

elseif graphNo == 42
    newICs = initialConditionsHigh;
    newICs(6) = 1;
    [tProt,resultsProt] = ode23t(@AtheroEqnYears, timePeriod, newICs, options);
    entityToModel = 18;
    plot(tH/365, resultsHigh(:, entityToModel)/(10^4), highFormat, tH/365, resultsProt(:, entityToModel)/(10^4), medFormat);
     title('OxLDL Concentrations - Reduced PLA2');
    xlabel('Number of Years');
    ylabel('Lipoprotein Count (� 10^4)');
    h_legend = legend('Normal Proteoglycans', 'Reduced PLA2');
    
elseif graphNo == 43
    %Have to generate this one manually as I'm changing parameters and I don't have a way to consistantly do this yet

    paras(128) = paras(128) * 3;
    
    [thPDGF,resultsHighPDGF] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsHigh, options, flux, paras);
    [tmhPDGF,resultsMedHighPDGF] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedHigh, options, flux, paras);
    [tmPDGF,resultsMedPDGF] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMed, options, flux, paras);
    [tmlPDGF,resultsMedLowPDGF] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsMedLow, options, flux, paras);
    [tlPDGF,resultsLowPDGF] = ode23t(@AtheroEqnYearsParaSearch, timePeriod, initialConditionsLow, options, flux, paras);

    entityToModel = 65;
    plothandle = plot(tH/365, sum(resultsHigh(:, entityToModel),2)/(10^4), highFormat, tM/365, sum(resultsMed(:, entityToModel),2)/(10^4), medFormat, tL/365, sum(resultsLow(:, entityToModel),2)/(10^4), lowFormat, tH/365, sum(resultsHighPDGF(:, entityToModel),2)/(10^4), 'k', tM/365, sum(resultsMedPDGF(:, entityToModel),2)/(10^4), 'k', tL/365, sum(resultsLowPDGF(:, entityToModel),2)/(10^4), 'k');
   
        hold on;
    xvec = tH/365;
    yvecHigh = sum(resultsHighPDGF(:, entityToModel),2)/(10^4);
    yvecMed = sum(resultsMedPDGF(:, entityToModel),2)/(10^4);
    yvecLow = sum(resultsLowPDGF(:, entityToModel),2)/(10^4);
    markers = plot(xvec(1:1000:end), yvecHigh(1:1000:end), 'o', xvec(1:800:end), yvecMed(1:800:end), 'p', xvec(1:1000:end), yvecLow(1:1000:end), 'd');
    hold off;
    for i = 1:3
    markers(i).MarkerFaceColor = 'black';
    markers(i).MarkerEdgeColor = 'black';
    end
    title('Smooth Muscle Cell Concentrations - Increased PDGF');
    xlabel('Number of Years');
    ylabel('Cell Count (� 10^4)');
    h_legend = legend([plothandle(1:3);markers], 'LDL - 190 mg/dL', 'LDL - 120 mg/dL', 'LDL - 50 mg/dL',  'LDL - 190 mg/dL Inc PDGF', 'LDL - 120 mg/dL Inc PDGF', 'LDL - 50 mg/dL Inc PDGF');

elseif graphNo == 44
    rtP = resultsMedHigh;
    resultsToPlot(1, :) = rtP(:, 18) + rtP(:, 22);
    resultsToPlot(2, :) = rtP(:,27) + rtP(:,39) + rtP(:,40) + rtP(:,41) + rtP(:,42) + rtP(:,43) + rtP(:,44);
    resultsToPlot(3, :) = rtP(:, 65);
    plot(tH/365, resultsToPlot(1, :) /(10^4), highFormat, tH/365, resultsToPlot(2, :) /(10^4), medFormat, tH/365, resultsToPlot(3, :) /(10^4), lowFormat);
    title('Relative Cell Concentrations (LDL - 150 mg/dL)');
    xlabel('Number of Years');
    ylabel('Cell Counts (� 10^4)');
    h_legend = legend('Monocytes/Foam Cells', 'T Cells', 'Smooth Muscle Cells');
    ax = gca;
    ax.XLim= [40 80];
elseif graphNo == 45
    plot(tH/365, resultsHigh(:,39), tH/365 , resultsHigh(:,40), tH/365, resultsHigh(:,41), tH/365 , resultsHigh(:,42), tH/365, resultsHigh(:,43), tH/365 , resultsHigh(:,44));
    h_legend = legend('Th1', 'Th2', 'Th17', 'TFH', 'TNK', 'TReg');
    title('T Cell Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Count');
    %h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL', 'LDL - 150 mg/dL, HDL - 45 mg/dL', 'LDL - 110 mg/dL, HDL - 45 mg/dL', 'LDL - 90 mg/dL, HDL - 50 mg/dL', 'LDL - 50 mg/dL, HDL - 50 mg/dL');
elseif graphNo == 46
    %Test reverse cholesterol transport
    newIC = resultsHigh(365*40, :);
    newIC(1) = 50 * 1000;
    newIC(10) = 50 * 1000;
    [tRCTHL,resultsRCTHighLow] = ode23t(@AtheroEqnYears, 0:365*40, newIC, options);
    newResults = resultsHigh(1:365*40, :);
    newResults(size(newResults,1) + 1: size(newResults,1) + size(resultsRCTHighLow,1), :) = resultsRCTHighLow;
    toPlot = 9;
    plot(tH/365, newResults(:,toPlot), highFormat);
    
        title('Oxidised LDL Concentrations');
    xlabel('Number of Years');
    ylabel('Lipoprotein Count');
    h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL --> LDL - 50 mg/dL, HDL - 50 mg/dL');
elseif graphNo == 47
    %Test reverse cholesterol transport
    newIC = resultsHigh(365*40, :);
    newIC(1) = 50 * 1000;
    newIC(10) = 50 * 1000;
    [tRCTHL,resultsRCTHighLow] = ode23t(@AtheroEqnYears, 0:365*40, newIC, options);
    newResults = resultsHigh(1:365*40, :);
    newResults(size(newResults,1) + 1: size(newResults,1) + size(resultsRCTHighLow,1), :) = resultsRCTHighLow;
    toPlot = 65;
    plot(tH/365, newResults(:,toPlot), highFormat);
    
    title('Smooth Muscle Cell Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Abundance');
    h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL --> LDL - 50 mg/dL, HDL - 50 mg/dL');
elseif graphNo == 48
    %Test reverse cholesterol transport
    newIC = resultsHigh(365*40, :);
    newIC(1) = 50 * 1000;
    newIC(10) = 50 * 1000;
    [tRCTHL,resultsRCTHighLow] = ode23t(@AtheroEqnYears, 0:365*40, newIC, options);
    newResults = resultsHigh(1:365*40, :);
    newResults(size(newResults,1) + 1: size(newResults,1) + size(resultsRCTHighLow,1), :) = resultsRCTHighLow;
    toPlot = 18;
    plot(tH/365, newResults(:,toPlot), highFormat);
    
    title('Foam Cell Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Abundance');
    h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL --> LDL - 50 mg/dL, HDL - 50 mg/dL');
    
elseif graphNo == 49
    %Test reverse cholesterol transport
    newIC = resultsHigh(365*40, :);
    newIC(1) = 50 * 1000;
    newIC(10) = 50 * 1000;
    [tRCTHL,resultsRCTHighLow] = ode23t(@AtheroEqnYears, 0:365*40, newIC, options);
    newResults = resultsHigh(1:365*40, :);
    newResults(size(newResults,1) + 1: size(newResults,1) + size(resultsRCTHighLow,1), :) = resultsRCTHighLow;
    toPlot = 22;
    plot(tH/365, newResults(:,toPlot), highFormat);
    
    title('Macrophage Concentrations');
    xlabel('Number of Years');
    ylabel('Cell Abundance');
    h_legend = legend('LDL - 190 mg/dL, HDL - 40 mg/dL --> LDL - 50 mg/dL, HDL - 50 mg/dL');
      
end
ax = gca;
ax.YTick = 0:(ax.YLim(2)/2):ax.YLim(2);
ax.XTick = 0:(ax.XLim(2)/2):ax.XLim(2);
set(gca, 'FontSize', 27);
set(gca, 'FontWeight', 'bold');
set(findall(gca, 'Type', 'Line'),'LineWidth',3);
set(h_legend, 'FontSize', 19);
set(h_legend, 'Location', 'northwest');

