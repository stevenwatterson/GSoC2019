function[y,ds1, ds2] = AtherosclerosisPathwayCompareLHYears(str)

ds1 = AtherosclerosisPathway2016Years(str, 'high');
ds2 = AtherosclerosisPathway2016Years(str, 'low');
t = 0:1:(80*365);
clf;
for i = 1:size(str, 2)
        hold on;
        plot(t/365, ds1(:,str(i)), t/365, ds2(:, str(i)));
        hold off;
end;

y = ds1(80*365, str) / ds2(80*365,str);