function output = AtheroEqnYears(t,y, flux, p1, p2, p3)  
j_ll = 0.0000000000005;
k_lpb = 266;%34.375; %6.9 uM
k_oxl = 10625;
k_moxl = 123;
k_oxh = 0.10625;
k_moxh = 180625;%2812500;
j_hl = 0.0000004625;
k_hpb = 266;
k_mcpecMM = 0.027 * 5;%0.0313;
km_mcpec = 10500000;
km_mcpil1b = 2;
k_mcpl = 0.0000017886;
km_mcpl = 62.5;
d_mcpl = 0.00065;
k_mcpi = 100;%11000;%0.00002 * 96000;%0.0000000625;
d_mcpi = 1.73;%0.00053125;
d_mcsf = 4.1472;%2;
k_mono = 0.00105125;
k_monoL = 0.0080375;
k_mdiff = 0.0994;
k_fc = 18 * 30;%0.18;
k_fcr = k_fc*30;%0.85;
km_fc = 6000000;
km_fco = 6000000;
d_fc = 0.0075;%0.00003125;
k_mcsf = 50; 
d_mc = 0.05;
k_ifng1 = 1200000;%700000;
k_mifng1 = 75000000;
k_ifng17 = 1200000;%700000;%0.000003125;
k_mifng17 = 75000000;%0.000003125;
d_ifng = 0.69;%0.1;
k_rct = 0.000000015; %% REMEMBER TO SWITCH BACK ON
k_cx9 =  3800 * 5;
k_cx10 = 2500 * 5;
k_cx11 = 1100 * 5;
k_mcx9 = 950000000; 
k_mcx10 = 125000000;
k_mcx11 = 65000000;
k_ccl5 = 130;
d_cx9 = 0.000005; 
d_cx10 = 0.000005;
d_cx11 = 0.00000625;
d_ccl5 = 0.03125;
kt_mcx9 =  150000;%p1;%300000;
kt_mcx10 = 225000;%p1;%400000; 
kt_mcx11 = 150000;%p1;%400000; 
kt_mc = 2000;
kmm2_tl = 1650;%p2;%25000;
k_tt = 0.0004;
k_il1m = 0.8;%0.000003125;
k_il1s = 0.8;%0.000003125;
d_il1 = 2;%0.00625;
k_il2c = 7.5;%66001;
k_il2t1 = 7.5;%66001;
d_il2 = 2;%0.0625;
k_il4t2 = 1;%0.0000043125;
k_il4tfh = 1;
d_il4 = 2;%0.000003125;
k_il5 = 0.9;%0.003125;
d_il5 = 2;%0.00625;
k_il6m = 180;%0.00001;
k_il6s = 180;%0.00001;
k_il6c = 180;%0.00001;
d_il6 = 2;%0.625;
k_il10r = 0.375;
k_il10b1 = 0.375;
k_il10b2 = 0.375;
k_il10t2 = 0.375;
d_il10 = 2;%0.0625;
k_il12b = 0.375;%0.00081;%0.0000001375;
k_il12d = 0.375;%0.00081;%0.0000001375;
k_il12m = 0.375;%0.00081;%0.0000001375;
k_il12f = 0.375;%0.00081;%0.0000001375;
d_il12 = 2;%0.0003125;
k_il18 = 2;
d_il18 = 2;%0.0003125;
k_il21 = 21;%0.0005125;
d_il21 = 2;%0.00003125;
k_tgfr = 0.03;%45;%0.001;
k_tgfs = 0.03;%45;%0.001;
k_tgfm = 0.03;%45;%0.001;
km_tgf = 100000;
d_tgf = 2;
d_th1 = 0.06;%0.033;
d_th2 = 0.06;%0.033;
d_th17 = 0.06;%0.033;
d_tfh = 0.06;%0.033;
d_tnk = 0.06;%0.033;
d_treg = 0.06;%0.033;
d_t0 = 0.02;
k_tnfFC = 2.2;%4;%0.0275;
k_tnfMC = 2.2;%4;%0.0275;
k_tnfT1 = 2.2;%4;%0.0275;
k_tnfT17 = 2.2;%4;%0.0275;
d_tnf = 2;
k_mmp1 = 0.002;
d_mmp1 = 4.32;
k_mmp2 = 0.4;
d_mmp2 = 4.32;
k_mmp3 = 0.0004;
d_mmp3 = 4.32;
k_mmp9 = 20;%0.0000028125;
d_mmp9 = 4.32;
k_mmp13 = 0.25;%0.000028125;
d_mmp13 = 4.32;
c_mmp1 = 0.0000001;
c_mmp2 = 0.0000001;
c_mmp3 = 0.0000001;
c_mmp9 = 0.0000001;
c_mmp13 = 0.0000001;
c_timp1 = 0.0000001;
c_timp2 = 0.0000001;
c_timp3 = 0.0000001;
c_timp4 = 0.0000001;
k_timp1 = 200;
d_timp1 = 20;%21.6;
k_timp2 = 200;
d_timp2 = 20;%21.6;
k_timp3 = 200;
d_timp3 = 20;%21.6;
k_timp4 = 200;
d_timp4 = 20;%21.6;
k_chy = 0.0033125;
d_chy = 0.0003125;
k_try = 0.0042;
d_try = 0.0003125;
k_pdgf = 0.15;%7500;
d_pdgf = 2.4;%3.84;
d_ela = 0.000000257;
k_coll = 25;
d_coll = 0.0333;
re_coll = 0.000000257;
k_smc = 9000;%9500;%6700000;%9500;
k_msmcp = 500;%800000;%500000;
k_msmcc = 500;%500000;%200000;
d_smc = 0.144;
k_il1bl = 10.125;
d_il1bl = 0.03125;
k_clhdli = 0.0000006;
k_clhdll = 0.0003125;%0.0003125;
k_ehdl = 0.0003125;
k_hdlt = 0.0003125;
k_bile = 0.000856;%0.000000003125;
k_chyi = 0.03125;
k_chyl = 0.0001125;
k_chyrl = 0.0006125;
k_iccr = 0.01;%0.01/32;
k_vldll = 1;%3.125;
k_vldlt = 0.016;%0.00000003125;
k_idl = 0.00000003125;
k_ldl = 0.0000000003125;
k_tgv = 0.000000025125;
k_tgi = 0.000000025125;
k_ffav = 0.00000000003125;
k_ffai = 0.00000000003125;
k_nam = 0.000000015;
d_nam = 0.33;
k_il17 = 30;
d_il17 = 2;
k_th1 = 8.097;
k_mil12 = 100000;
k_mil18 = 100000;
k_th2 = 8.1882;
k_mil4 = 100000;
k_mil10 = 100000;
k_th17 = 0.644;
k_mtgfb = 100000;
k_tfh =  66.435;
k_mil6 = 1000000;
k_mil21 = 1000000;
k_tnk =  0.000014;
k_treg = 0.00625;
k_ela = 1938;
k_mela = 100000;
k_iegf = 2;
k_mil1b = 50000;
k_mccl5 = 10000;
k_tt3i = 1000000;
k_il10m = 0.375;


    
output(1,1) = 0;%LDL in Lumen
output(2,1) = j_ll*y(1)^3 - k_lpb*y(2)*y(4);%LDL in Intima
output(3,1) = k_lpb*y(2)*y(4) - k_oxl* y(3) * y(5) * y(6) * y(7) * y(8)/(k_moxl + y(3));%PB-LDL
output(4,1) = 0; %Proteoglycans
output(5,1) = 0;%k_oxr * y(18) * y(65) * y(15) / ((k_moxr + y(65)) * (k_moxrm + y(18)))  - (k_pbl * y(3) * y(5) * y(6) * y(7) * y(8)/((k_moxl + y(3))) + k_pbh* y(12) * y(5) * y(6) * y(7) * y(8)/(k_moxh + y(12))); %Free oxygen radicals
output(6,1) = 0; %PLA
output(7,1) = 0; %SMase
output(8,1) = 0; %Lipoxygenase
output(9,1) = k_oxl * y(3) * y(5) * y(6) * y(7) * y(8)/((k_moxl + y(3))) -  k_fcr*y(22)*y(9)*y(19)/((km_fc + y(22)) * ((km_fco + y(9)))); %oxLDL
output(10,1) = 0; %HDL in Lumen
output(11,1) = j_hl*y(10)^2 - k_hpb * y(11) * y(4);%HDL in Intima
output(12,1) = k_hpb * y(11) * y(4) - k_oxh* y(12) * y(5) * y(6) * y(7) * y(8)/(k_moxh + y(12)) - k_clhdli * y(18) * y(69) * y(70) * (y(12)); %PB-HDL
output(13,1) = k_oxh* y(12) * y(5) * y(6) * y(7) * y(8)/(k_moxh + y(12)); %oxHDL
    
output(14,1) = k_mcpecMM*y(15)*y(9)*y(67)/((km_mcpec + y(9)) * (km_mcpil1b + y(67))) + k_mcpl * y(21)/(km_mcpl + y(21)) - d_mcpl*y(14);%MCP-1 in Lumen
output(15,1) = 0;% ECs
output(16,1) = k_mono*y(14) - k_monoL*y(16); %Monocytes in lumen
output(17,1) = k_monoL*y(16) - k_mdiff*y(17)*y(20);%Monocytes in Intima
output(18,1) = k_fc*y(22)*y(9)*y(19)/((km_fc + y(22)) * ((km_fco + y(9)))) - d_fc * y(18) - k_rct * (y(12)) * y(69) * y(70) * y(18); %FCs
output(19,1) = k_ifng1 * y(39)/ (k_mifng1 + y(39)) + k_ifng17 * y(41)/(k_mifng17 + y(41)) - d_ifng * y(19);%k_ifng * (y(39) * y(41))/((km_ifng + y(39)) * (km_ifng17 + y(41)))  - d_ifng * y(19);
output(20,1) = k_mcsf * y(22) - d_mcsf * y(20); %MCSF
output(21,1) = k_mcpi * y(18) - d_mcpi * y(21) - k_mcpl * y(21)/(km_mcpl + y(21)); %MCP-1 in Intima
output(22,1) = k_mdiff*y(17)*y(20) - k_fc*y(22)*y(9)*y(19)/((km_fc + y(22)) * ((km_fco + y(9)))) - d_mc * y(22);% Macrophages
output(23,1) = k_cx9 * y(15) * y(19)/(k_mcx9 + y(19)) - d_cx9 * y(23); %CXCL9
output(24,1) = k_cx10 * y(15) * y(19)/(k_mcx10 + y(19))  - d_cx10 * y(24); %CXCL10
output(25,1) = k_cx11 * y(15) * y(19)/(k_mcx11 + y(19)) - d_cx11 * y(25); % CXCL11;
   



%output(26,1) = k_mtl9 * y(23)  + k_mtl10 * y(24) + k_mtl11 * y(25) + k_mtlc * y(68) - k_tt * y(26); 
output(26,1) = kmm2_tl * y(23) * y(24) * y(25) * y(68)/((kt_mcx9 + y(23)) * (kt_mcx10 + y(24)) * (kt_mcx11 + y(25)) * (kt_mc + y(68))) - k_tt * y(26);
output(27,1) = k_tt * y(26) - k_th1 * y(27) * y(34) * y(35)/((k_mil12 + y(34)) * (k_mil18 + y(35)))  - k_th2 * y(27) * y(30) * y(33)/((k_mil4 + y(30)) * (k_mil10 + y(33))) - k_th17 * y(27) * y(33) * y(38)/((k_mil10 + y(33)) * (k_mtgfb + y(38))) - k_tfh * y(27) * y(32) * y(36)/((k_mil6 + y(32)) * (k_mil21 + y(36)))- k_tnk * y(27) - k_treg * y(27) * y(33) * y(38)/((k_mil10 + y(33)) * (k_mtgfb + y(38))) - d_t0 * y(27); % T Cell in Intima
%output(27,1) = k_tt * y(26) - k_th1 * y(27) * y(34) * y(35)/((k_mil12 + y(34)) * (k_mil18 + y(35)))  - k_th2 * y(27) * y(30) * y(33)/((k_mil4 + y(30)) * (k_mil10 + y(33))) - k_th17 * y(27) * y(33) * y(38)/((k_mil10 + y(33)) * (k_mtgfb + y(38))) - k_tfh * y(27) * y(32) * y(36) - k_tnk * y(27) - k_treg * y(27) * y(33) * y(38) - d_t0 * y(27); % T Cell in Intima
output(28,1) = k_il1m * y(18) + k_il1s * y(65) - d_il1 * y(28); % IL-1
output(29,1) = k_il2t1 * y(39) + k_il2c * y(62) - d_il2 * y(29); % IL-2
%output(30,1) = k_il4 * (y(40) + y(42)) - d_il4 * y(30); % IL-4
output(30,1) = k_il4t2 * y(40) + k_il4tfh * y(42) - d_il4 * y(30); % IL-4
output(31,1) = k_il5 * y(40) - d_il5 * y(31); % IL-5
output(32,1) = k_il6m * y(18) + k_il6s * y(65) + k_il6c * y(64) - d_il6 * y(32); % IL-6
output(33,1) = k_il10m * y(22) + k_il10r * y(44) + k_il10b1 * y(60) + k_il10b2 * y(61) + k_il10t2 * y(40) - d_il10 * y(33); % IL-10
output(34,1) = k_il12b * y(61) + k_il12d * y(62) + k_il12m * y(22) + k_il12f * y(18) - d_il12 * y(34); % IL-12
output(35,1) = k_il18 * y(22) - d_il18 * y(35); % IL18;
%output(35,1) = k_test * y(1) - d_il18 * y(35); % IL18;
%output(35,1) = 0; % IL18;
output(36,1) = k_il21 * y(43) - d_il21 * y(36); % IL-21
output(37,1) = 0; % IL-33
   
%output(38,1) = k_tgf * y(44) / (km_tgf + y(44)) - d_tgf * y(38); % TGF-Beta
output(38,1) = k_tgfr * y(44) + k_tgfs * y(65) + k_tgfm * y(22) - d_tgf * y(38); % TGF-Beta


%output(39,1) = k_th1 * y(27) * y(34) * y(35) - d_th1 * y(39); %Th1
output(39,1) = k_th1 * y(27) * y(34) * y(35)/((k_mil12 + y(34)) * (k_mil18 + y(35)))  - d_th1 * y(39); %Th1

output(40,1) = k_th2 * y(27) * y(30) * y(33)/((k_mil4 + y(30)) * (k_mil10 + y(33))) - d_th2 * y(40); % Th2
output(41,1) = k_th17 * y(27) * y(33) * y(38)/((k_mil10 + y(33)) * (k_mtgfb + y(38))) - d_th17 * y(41); %Th17
%output(42,1) = k_tfh * y(27) * y(32) * y(36) - d_tfh * y(42); %Tfh
output(42,1) = k_tfh * y(27) * y(32) * y(36)/((k_mil6 + y(32)) * (k_mil21 + y(36))) - d_tfh * y(42); %Tfh
output(43,1) = k_tnk * y(27) - d_tnk * y(43); %Tnk
output(44,1) = k_treg * y(27) * y(33) * y(38)/((k_mil10 + y(33)) * (k_mtgfb + y(38))) - d_treg * y(44); %Treg
output(45,1) = k_tnfFC * y(18) * y(88)/(1+y(52)/k_tt3i) + k_tnfMC * y(64) * y(88)/(1+y(52)/k_tt3i) + k_tnfT1 * y(39) * y(88)/(1+y(52)/k_tt3i) + k_tnfT17 * y(41) * y(88)/(1+y(52)/k_tt3i)  - d_tnf * y(45); %TNF
   
output(46,1) = k_mmp1 * y(18) * y(54) * y(55) - c_mmp1 * y(46) * (y(50) + y(51) + y(52) + y(53))  - d_mmp1 * y(46); %MMP1
output(47,1) = k_mmp3 * y(18) * y(54) * y(55) - c_mmp3 * y(47) * (y(50) + y(51) + y(52) + y(53)) - d_mmp3 * y(47) ;%MMP3
output(48,1) = k_mmp9 * y(18) * y(63) - c_mmp9 * y(48) * (y(50) + y(51) + y(52) + y(53)) - d_mmp9 * y(48); %MMP9
output(49,1) = k_mmp13 * y(18) - c_mmp13 * y(49) * (y(50) + y(51) + y(52) + y(53)) - d_mmp13 * y(49) ; %MMP13
output(50,1) = k_timp1 * y(22)*y(54) - c_timp1 * y(50) * (y(46) + y(47) + y(48) + y(49) + y(89))  - d_timp1 * y(50);%TIMP1
output(51,1) = k_timp2 * y(22) - c_timp2 * y(51) * (y(46) + y(47) + y(48) + y(49) + y(89))  - d_timp2 * y(51);%TIMP2
output(52,1) = k_timp3 * y(22) - c_timp3 * y(52) * (y(46) + y(47) + y(48) + y(49) + y(89)) - d_timp3 * y(52);%TIMP3
output(53,1) = k_timp4 * y(22) - c_timp4 * y(53) * (y(46) + y(47) + y(48) + y(89)) - d_timp4 * y(53);%TIMP4
    
output(54,1) = k_chy * y(64) - d_chy * y(54); %Chymase
output(55,1) = k_try * y(64) - d_try * y(55); %Tryptase
%output(56,1) = k_pdgf * y(18)/(km_pdgf + y(18)) - d_pdgf * y(56); %PDGF
output(56,1) = k_pdgf * y(18) - d_pdgf * y(56); %PDGF
output(57,1) = 0;
%output(58,1) = k_ela * y(65) * y(38) / y(57) - d_ela * y(58) * (y(46)+ y(47)+ y(48)+ y(49) + y(89)) ; %Elastin


output(58,1) = k_ela * y(65) * y(38) / (k_mela * (1 + y(57)/k_iegf) + y(65))  - d_ela * y(58) * (y(46)+ y(47)+ y(48)+ y(49) + y(89)) ; %Elastin
%output(59,1) = k_coll * y(65) - d_coll * y(59) * (y(46) + y(48) + y(49)); %Collagen
output(59,1) = k_coll * y(65) - d_coll * y(59) - re_coll * y(59) * (y(46) + y(47) + y(48) + y(49) + y(89)); %Collagen
    
output(60,1) = 0;
output(61,1) = 0;
output(62,1) = 0;
output(63,1) = 0;
output(64,1) = 0;
%output(65,1) = real(k_smc * y(21)^(0.25) * y(56)/((k_msmcp + y(56)) * (k_msmcc + y(21)^(0.25))) )- d_smc * y(65); %SMCs
output(65,1) = k_smc * y(21) * y(56)/((k_msmcp + y(56)) * (k_msmcc + y(21)))- d_smc * y(65); %SMCs
output(66,1) = 0;



output(67,1) = k_il1bl * y(66) * y(16)/(k_mil1b + y(16)) - d_il1bl * y(67);%IL1b Lumen
%output(67,1) = k_il1bl * y(66) - d_il1bl * y(67);%IL1b Lumen

%output(68,1) = k_ccl5 * y(66) - d_ccl5 * y(68); %CCL5
output(68,1) = k_ccl5 * y(66)  * y(16)/(k_mccl5 + y(16)) - d_ccl5 * y(68); %CCL5
output(69,1) = 0;
output(70,1) = 0;
    
output(71,1) = k_clhdli * y(18) * y(69) * y(70) * (y(12)) - k_clhdll * y(71);
output(72,1) = k_clhdll * y(71) - k_ehdl * y(72); %CL-HDL in Liver
output(73,1) = k_ehdl * y(72) - k_hdlt * y(73); %Empty HDL in Liver
output(74,1) = k_nam * y(18) * y(69) * y(70) * (y(12)) - d_nam * y(74); %NON-ACTIVATED MACROPHAGE
output(75,1) = k_il17 * y(41) - d_il17 * y(75); %IL-17
output(76,1) = k_bile * y(72); %Bile Acids
output(77,1) = 0; % Cholesterol in Intestine
output(78,1) = k_chyi * y(77) - k_chyl * y(78); %Chylomicron in Intestine
output(79,1) = k_chyl * y(78) - k_chyrl * y(81) * y(79); %Chylomicron Lumen
output(80,1) = k_chyrl * y(81) * y(79) - k_iccr * y(80);%Chylomicron Remnants
output(81,1) = 0; %Lipoprotein Lipase
output(82,1) = k_iccr * y(80) ; %Cholesterol in Liver
output(83,1) = k_vldll * y(82) - k_vldlt * y(83); %VLDL in liver
output(84,1) = k_vldlt * y(83) - k_idl * y(84) * y(81); %VLDL in lumen
output(85,1) = k_idl * y(84) * y(81) - k_ldl * y(81) * y(85); %IDL
output(86,1) = k_tgv * y(84) * y(81) + k_tgi * y(85) * y(81); %TGs in Lumen
output(87,1) = k_ffav * y(84) * y(81) + k_ffai * y(85) * y(81); %FFA
output(88,1) = 0; %TACE
output(89,1) = k_mmp2 * y(18) - c_mmp2 * y(89) * (y(50) + y(51) + y(52) + y(53)) - d_mmp2 * y(89); %MMP2
    
if(~exist('flux', 'var'))
    flux = 0;
end
if(flux)
    %%%%%%%FLUX%%%%
    fID = fopen('exp.txt','a');
    fprintf(fID, 'T%f - Time Point \n', t);
    fprintf(fID, '(2) - LDLIFromL: %f LDLBoundToPGs: %f \n', j_ll*y(1)^3, k_lpb*y(2)*y(4));
    fprintf(fID, '(3) -  PB-LDL: %f LDLOxidation: %f \n', k_lpb*y(2)*y(4), k_oxl* y(3) * y(5) * y(6) * y(7) * y(8)/(k_moxl + y(3)));
    fprintf(fID, '(5) -  ROSProd: LDLROSConsumption: HDLROSConsumption: \n');
    %fprintf(fID, '(5) -  ROSProd: %f LDLROSConsumption: %f HDLROSConsumption: %f \n',k_oxr * y(18) * y(65) * y(15) / ((k_moxr + y(65)) * (k_moxrm + y(18))), k_pbl * y(3) * y(5) * y(6) * y(7) * y(8)/((k_moxl + y(3))),  k_pbh* y(12) * y(5) * y(6) * y(7) * y(8)/(k_moxh + y(12)));
    fprintf(fID, '(9) - LDLOxidation: %f Phagocytosis: %f \n', k_oxl * y(3) * y(5) * y(6) * y(7) * y(8)/((k_moxl + y(3))), k_fcr*y(22)*y(9)*y(19)/((km_fc + y(22)) * ((km_fco + y(9)))));
    fprintf(fID, '(11) - HDLIfromL: %f HDLBoundToPGs: %f \n', j_hl*y(10), k_hpb * y(11) * y(4));
    fprintf(fID, '(12) - HDLBoundToPGs: %f HDLOxidation: %f RCT: %f \n', k_hpb * y(11) * y(4), k_oxh* y(12) * y(5) * y(6) * y(7) * y(8)/(k_moxh + y(12)), k_clhdli * y(18) * y(69) * y(70) * (y(12)));
    fprintf(fID, '(13) - HDLOxidation: %f \n', k_oxh* y(12) * y(5) * y(6) * y(7) * y(8)/(k_moxh + y(12)));
        
    fprintf(fID, '(14) - MCPFromI: %f MCPProductionECs: %f MCPDeg: %f \n', k_mcpl * y(21)/(km_mcpl + y(21)), k_mcpecMM*y(15)*y(9)*y(67)/((km_mcpec + y(9)) * (km_mcpil1b + y(67))), d_mcpl*y(14));
    fprintf(fID, '(16) - MonoRecruitment: %f MonoTransfer: %f \n',  k_mono*y(14), k_monoL*y(16));
    fprintf(fID, '(17) - MonoTransfer: %f MonoDiff: %f \n', k_monoL*y(16), k_mdiff*y(17)*y(20));
    fprintf(fID, '(18) - FoamCellFormation: %f FCDeath: %f RCT: %f \n', k_fc*y(22)*y(9)*y(19)/((km_fc + y(22)) * ((km_fco + y(9)))), d_fc * y(18), k_rct * (y(12)) * y(69) * y(70) * y(18));
    fprintf(fID, '(19) - IFNGDeg: %f IFNGProdTh1: %f IFNGProdTh17: %f \n', d_ifng*y(19),  k_ifng1 * y(39), k_ifng17 * y(41) );
    fprintf(fID, '(20) - MCSFProd: %f MCSFDeg: %f \n', k_mcsf * y(22), d_mcsf * y(20));
    fprintf(fID, '(21) - MCPIProd: %f MCPIDeg: %f MCPItoL: %f \n', k_mcpi * y(18), d_mcpi * y(21), k_mcpl * y(21)/(km_mcpl + y(21)));
    fprintf(fID, '(22) - MonoDiff: %f FoamCellFormation: %f \n', k_mdiff*y(17)*y(20), k_fc*y(22)*y(9)*y(19)/((km_fc + y(22)) * ((km_fco + y(9)))));
    fprintf(fID, '(23) - CXCL9Form: %f CXCL9Deg: %f \n', k_cx9 * y(15) * y(19)/(k_mcx9 + y(19)), d_cx9 * y(23));
    fprintf(fID, '(24) - CXCL10Form: %f CXCL10Deg: %f \n', k_cx10 * y(15) * y(19), d_cx10 * y(24));
    fprintf(fID, '(25) - CXCL11Form: %f CXCL11Deg: %f \n', k_cx11 * y(15) * y(19), d_cx11 * y(25));
        
    fprintf(fID, '(26) - TCellRecr: %f TCellTransfer: %f \n', kmm2_tl * y(23) * y(24) * y(25) * y(68)/((kt_mcx9 + y(23)) * (kt_mcx10 + y(24)) * (kt_mcx11 + y(25)) * (kt_mc + y(68))) , k_tt * y(26));
    fprintf(fID, '(27) - TCellTransfer: %f Th1Diff: %f Th2Diff: %f Th17Diff: %f TFHDiff: %f TNKDiff: %f TRegDiff: %f \n', k_tt * y(26), k_th1 * y(27) * y(34) * y(35), k_th2 * y(27) * y(30) * y(33), k_th17 * y(27) * y(28) * y(33) * y(38), k_tfh * y(27) * y(32) * y(36), k_tnk * y(27), k_treg * y(27) * y(33) * y(38) );
    fprintf(fID, '(28) - IL1Prod: %f IL1Deg: %f \n',  k_il1m * y(18) + k_il1s * y(65), d_il1 * y(28));
    fprintf(fID, '(29) - IL2Prod: %f IL2Deg: %f \n', k_il2t1 * y(39) + k_il2c * y(62), d_il2 * y(29));
    fprintf(fID, '(30) - IL4Prod: %f IL4Deg: %f \n', k_il4 * (y(40) + y(42)), d_il4 * y(30));
    fprintf(fID, '(31) - IL5Prod: %f IL5Deg: %f \n',k_il5 * y(40), d_il5 * y(31));
    fprintf(fID, '(32) - IL6Prod: %f IL6Deg: %f \n', k_il6 * (y(18) + y(65) + y(64)), d_il6 * y(32));
    fprintf(fID, '(33) - IL10Prod: %f IL10Deg: %f \n',k_il10 * (y(44) + y(60) + y(61)),  d_il10 * y(33));
    fprintf(fID, '(34) - IL12Prod: %f IL12Deg: %f \n',k_il12 * (y(61) + y(62)) * y(22), d_il12 * y(34));
    fprintf(fID, '(36) - IL21Prod: %f IL21Deg: %f \n', k_il21 * y(42), d_il21 * y(36));
    fprintf(fID, '(38) - TGFBProd: %f TGFBDeg: %f \n', k_tgf * y(44)/(km_tgf + y(44)), d_tgf * y(38));
    fprintf(fID, '(39) - Th1Diff: %f Th1Death: %f \n', k_th1 * y(27) * y(34) * y(35), d_th1 * y(39));
    fprintf(fID, '(40) - Th2Diff: %f Th2Death: %f \n', k_th2 * y(27) * y(30) * y(33), d_th2 * y(40));
    fprintf(fID, '(41) - Th17Diff: %f Th17Death: %f \n', k_th17 * y(27) * y(33) * y(38), d_th17 * y(41));
    fprintf(fID, '(42) - TFHDiff: %f TFHDeath: %f \n', k_tfh * y(27) * y(32) * y(36), d_tfh * y(42));
    fprintf(fID, '(43) - TNKDiff: %f TNKDeath: %f \n', k_tnk * y(27), d_tnk * y(43));
    fprintf(fID, '(44) - TRegDiff: %f TRegDeath: %f \n', k_treg * y(27) * y(33) * y(38), d_treg * y(44));
    fprintf(fID, '(45) - TNFProd: %f TNFDeg: %f \n', k_tnf * y(18) * y(64) * y(39) * y(41)/((km_tnf + y(18))* (km_tnf + y(39))),  d_tnf * y(45));
        
    fprintf(fID, '(46) - MMP1Prod: %f MMP1Deg: %f \n', k_mmp1 * y(18) * y(54) * y(55), d_mmp1 * y(46));
    fprintf(fID, '(47) - MMP3Prod: %f MMP3Deg: %f \n', k_mmp3 * y(18) * y(54) * y(55), d_mmp3 * y(47));
    fprintf(fID, '(48) - MMP9Prod: %f MMP9Deg: %f \n', k_mmp9 * y(18) * y(63), d_mmp9 * y(48));
    fprintf(fID, '(49) - MMP13Prod: %f MMP13Deg: %f \n', k_mmp13 * y(18), d_mmp13 * y(49));
    fprintf(fID, '(50) - TIMP1Prod: %f TIMP1Deg: %f \n', k_timp1 * y(22) * y(54), d_timp1 * y(50));
    fprintf(fID, '(51) - TIMP2Prod: %f TIMP2Deg: %f \n', k_timp2 * y(22), d_timp2 * y(51));
    fprintf(fID, '(52) - TIMP3Prod: %f TIMP3Deg: %f \n', k_timp3 * y(22), d_timp3 * y(52));
    fprintf(fID, '(53) - TIMP4Prod: %f TIMP4Deg: %f \n', k_timp4 * y(22), d_timp4 * y(53));
        
    fprintf(fID, '(54) - ChyProd: %f ChyDeg: %f \n', k_chy * y(64), d_chy * y(54));
    fprintf(fID, '(55) - TrypProd: %f TrypDeg: %f \n', k_try * y(64), d_try * y(55));
    fprintf(fID, '(56) - PDGFProd: %f PRGFDeg: %f \n', k_pdgf * y(18), d_pdgf * y(56));
    fprintf(fID, '(58) - ElastinProd: %f ElastinDeg: %f \n', k_ela * y(65) * y(38) / y(57), d_ela * y(58) * y(46)* y(47)* y(48)* y(49));
    fprintf(fID, '(59) - CollagenProd: %f CollagenDeg: %f \n', k_coll * y(65), d_coll * y(59) * (y(46) + y(48) + y(49)));
        
    fprintf(fID, '(65) - SMCProl: %f SMCDeath: %f \n',k_smc * y(21) * y(56)/((k_msmcp + y(56)) * (k_msmcc + y(21))), d_smc * y(65));
    fprintf(fID, '(67) - IL1BLProd: %f IL1BLDeath: %f \n',k_il1bl * y(66), d_il1bl * y(67));
    fprintf(fID, '(68) - CCL5Prod: %f CCL5Death: %f \n', k_ccl5 * y(15), d_ccl5 * y(68));
        
    fprintf(fID, '(71) - CLHDLIntima: %f CLHDLRemoval: %f \n', k_clhdli * y(18) * y(69) * y(70) * (y(12)), k_clhdll * y(71));
    fprintf(fID, '(72) - CLHDLLiver: %f RemHDLChol: %f \n', k_clhdll * y(71), k_ehdl * y(72));
    fprintf(fID, '(73) - EmptyHDL: %f HDLToIntima: %f \n', k_ehdl * y(72), k_hdlt * y(73));
        
    fprintf(fID, '(74) - NonActivatedMacrophages: %f NAMDeath: %f \n',k_nam * y(18) * y(69) * y(70) * (y(12)), d_nam * y(74));
        
    fprintf(fID, '(75) - IL17Prod: %f IL17Death: %f \n',k_il17 * y(41) ,  d_il17 * y(75));
    fprintf(fID, '(76) - BileProd: %f \n', k_bile * y(72));
    fprintf(fID, '(78) - ChyloProd: %f ChyloLumen: %f \n', k_chyi * y(77), k_chyl * y(78));
        
    fprintf(fID, '(79) - ChyloLumen: %f ChyloRem: %f \n', k_chyl * y(78), k_chyrl * y(81) * y(79));
    fprintf(fID, '(80) - ChyloRem: %f CholLiver: %f \n', k_chyrl * y(81) * y(79), k_iccr * y(80));
        
    fprintf(fID, '(82) - CholLiver: %f \n',k_iccr * y(80));
    fprintf(fID, '(83) - VLDLLiver: %f VLDLTransfer: %f \n',k_vldll * y(82), k_vldlt * y(83));
    fprintf(fID, '(84) - VLDLTransfer: %f IDLL: %f \n',k_vldlt * y(83), k_idl * y(84) * y(81));
    fprintf(fID, '(85) - IDLL: %f LDLL: %f \n', k_idl * y(84) * y(81), k_ldl * y(81) * y(85));
    fprintf(fID, '(86) - TGsVLDL: %f TGsIDL: %f \n', k_tgv * y(84) * y(81), k_tgi * y(85) * y(81));
    fprintf(fID, '(87) - FFAsVLDL: %f FFAsIDL: %f \n', k_ffav * y(84) * y(81), k_ffai * y(85) * y(81));
    fprintf(fID, '(89) - MMP2Prod: %f MMP2Deg: %f \nEOTP\n\n', k_mmp2 * y(18), d_mmp2 * y(89));
    %fprintf(fID, '\n');
        
    fclose(fID);
end